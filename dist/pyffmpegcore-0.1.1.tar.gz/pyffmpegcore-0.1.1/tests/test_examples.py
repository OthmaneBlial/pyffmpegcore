"""
Tests for example functions (mocked to avoid actual file I/O).
"""

import pytest
from unittest.mock import patch, MagicMock, mock_open
import os
import glob
from pyffmpegcore.runner import FFmpegRunner
from pyffmpegcore.probe import FFprobeRunner


class TestThumbnailExtraction:
    """Test thumbnail extraction functionality."""

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    def test_extract_thumbnail_basic(self, mock_run):
        """Test basic thumbnail extraction."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from examples.extract_thumbnail import extract_thumbnail

        result = extract_thumbnail("input.mp4", "output.jpg", "00:00:30")

        assert result is True
        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert "-i" in args
        assert "input.mp4" in args
        assert "-ss" in args
        assert "00:00:30" in args
        assert "-vframes" in args
        assert "1" in args

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    @patch('os.makedirs')
    def test_extract_multiple_thumbnails(self, mock_makedirs, mock_run):
        """Test multiple thumbnail extraction."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from examples.extract_thumbnail import extract_multiple_thumbnails

        timestamps = ["00:00:10", "00:00:30"]
        extract_multiple_thumbnails("input.mp4", "output_dir/", timestamps)

        # Should be called twice (once per timestamp)
        assert mock_run.call_count == 2
        assert mock_makedirs.called

    @patch('pyffmpegcore.probe.FFprobeRunner.probe')
    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    @patch('os.makedirs')
    def test_extract_smart_thumbnails(self, mock_makedirs, mock_run, mock_probe):
        """Test smart thumbnail extraction."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        mock_probe.return_value = {"duration": 120.0}  # 2 minutes

        from examples.extract_thumbnail import extract_smart_thumbnails

        extract_smart_thumbnails("input.mp4", "output_dir/", count=3)

        # Should extract 3 thumbnails at 40s, 80s, 120s intervals
        assert mock_run.call_count == 3
        assert mock_probe.called


class TestWaveformGeneration:
    """Test audio waveform generation functionality."""

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    def test_generate_waveform_image(self, mock_run):
        """Test basic waveform image generation."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from examples.generate_waveform import generate_waveform_image

        result = generate_waveform_image("input.mp3", "output.png")

        assert result is True
        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert "showwavespic" in " ".join(args)

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    def test_generate_detailed_waveform(self, mock_run):
        """Test detailed waveform generation."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from examples.generate_waveform import generate_detailed_waveform

        result = generate_detailed_waveform("input.mp3", "output.png")

        assert result is True
        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert "showwavespic" in " ".join(args)
        assert "colors=" in " ".join(args)

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    def test_generate_waveform_animation(self, mock_run):
        """Test animated waveform generation."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from examples.generate_waveform import generate_waveform_animation

        result = generate_waveform_animation("input.mp3", "output.mp4", duration=10)

        assert result is True
        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert "showwaves" in " ".join(args)
        assert "-t" in args
        assert "10" in args

    @patch('pyffmpegcore.probe.FFprobeRunner.probe')
    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    @patch('os.makedirs')
    def test_generate_waveform_with_metadata(self, mock_makedirs, mock_run, mock_probe):
        """Test waveform generation with metadata overlay."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        mock_probe.return_value = {
            "duration": 180.5,
            "audio": {"sample_rate": 44100, "channels": 2}
        }

        from examples.generate_waveform import generate_waveform_with_metadata

        generate_waveform_with_metadata("input.mp3", "output_dir/")

        # Should generate waveform and add metadata overlay
        assert mock_run.call_count == 2  # waveform + overlay
        assert mock_probe.called


class TestBatchImageConversion:
    """Test batch image conversion functionality."""

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    def test_convert_image_basic(self, mock_run):
        """Test basic image conversion."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        from examples.batch_convert_images import convert_image

        result = convert_image("input.png", "output.jpg", quality=85)

        assert result is True
        mock_run.assert_called_once()

    @patch('glob.glob')
    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    @patch('os.makedirs')
    def test_batch_convert_images(self, mock_makedirs, mock_run, mock_glob):
        """Test batch image conversion."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        mock_glob.return_value = ["image1.png", "image2.png"]

        from examples.batch_convert_images import batch_convert_images

        results = batch_convert_images("input_dir/", "output_dir/", ["*.png"], "jpg")

        assert results["total"] == 2
        assert results["successful"] == 2
        assert results["failed"] == 0
        assert mock_run.call_count == 2

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    @patch('glob.glob')
    @patch('os.makedirs')
    def test_optimize_images_for_web(self, mock_makedirs, mock_glob, mock_run):
        """Test web optimization with resizing."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        # Mock glob to return just one file per pattern
        mock_glob.return_value = ["large_image.jpg"]

        from examples.batch_convert_images import optimize_images_for_web

        results = optimize_images_for_web("input_dir/", "output_dir/")

        # Since glob returns the same list for each pattern, we get 6 files (1 per pattern)
        assert results["total"] == 6
        assert mock_run.called  # Should resize and convert

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    @patch('glob.glob')
    @patch('os.makedirs')
    def test_convert_to_webp_batch(self, mock_makedirs, mock_glob, mock_run):
        """Test WebP batch conversion."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        # Mock glob to return 2 files total (some patterns might return empty)
        mock_glob.side_effect = [["image1.jpg"], ["image2.png"], [], [], []]  # Different patterns return different results

        from examples.batch_convert_images import convert_to_webp_batch

        results = convert_to_webp_batch("input_dir/", "output_dir/", quality=80, lossless=False)

        assert results["total"] == 2
        # Should call convert_image for each file
        assert mock_run.call_count == 2


class TestVideoConcatenation:
    """Test video concatenation functionality."""

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    @patch('builtins.open', new_callable=mock_open)
    @patch('os.path.exists')
    def test_concatenate_videos_basic(self, mock_exists, mock_file, mock_run):
        """Test basic video concatenation."""
        mock_exists.return_value = True
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        # This would be in a new example file
        # For now, just test the FFmpeg concat functionality
        runner = FFmpegRunner()

        # Create concat file content
        concat_content = "file 'video1.mp4'\nfile 'video2.mp4'\n"

        with patch('builtins.open', mock_open(read_data=concat_content)) as mock_file:
            args = [
                "-f", "concat",
                "-safe", "0",
                "-i", "concat.txt",
                "-c", "copy",
                "-y", "output.mp4"
            ]

            result = runner.run(args)

            assert result.returncode == 0
            mock_run.assert_called_once()


class TestAudioProcessing:
    """Test advanced audio processing functionality."""

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    def test_audio_normalization(self, mock_run):
        """Test audio normalization."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        runner = FFmpegRunner()

        # Audio normalization using loudnorm filter
        args = [
            "-i", "input.wav",
            "-af", "loudnorm=I=-16:TP=-1.5:LRA=11",
            "-ar", "44100",
            "-y", "normalized.wav"
        ]

        result = runner.run(args)

        assert result.returncode == 0
        mock_run.assert_called_once()
        call_args = mock_run.call_args[0][0]
        assert "loudnorm" in " ".join(call_args)

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    def test_video_speed_adjustment(self, mock_run):
        """Test video speed adjustment."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        runner = FFmpegRunner()

        # Speed up video by 2x
        args = [
            "-i", "input.mp4",
            "-filter_complex", "[0:v]setpts=0.5*PTS[v];[0:a]atempo=2.0[a]",
            "-map", "[v]",
            "-map", "[a]",
            "-y", "sped_up.mp4"
        ]

        result = runner.run(args)

        assert result.returncode == 0
        mock_run.assert_called_once()
        call_args = mock_run.call_args[0][0]
        assert "setpts" in " ".join(call_args)
        assert "atempo" in " ".join(call_args)


class TestSubtitleHandling:
    """Test subtitle extraction and burning functionality."""

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    def test_extract_subtitles(self, mock_run):
        """Test subtitle extraction."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        runner = FFmpegRunner()

        # Extract subtitles to SRT format
        args = [
            "-i", "input.mkv",
            "-map", "0:s:0",  # First subtitle stream
            "-y", "subtitles.srt"
        ]

        result = runner.run(args)

        assert result.returncode == 0
        mock_run.assert_called_once()

    @patch('pyffmpegcore.runner.FFmpegRunner.run')
    def test_burn_subtitles(self, mock_run):
        """Test burning subtitles into video."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        runner = FFmpegRunner()

        # Burn subtitles into video
        args = [
            "-i", "input.mp4",
            "-vf", "subtitles=input.mkv:stream_index=0",
            "-c:a", "copy",
            "-y", "with_subtitles.mp4"
        ]

        result = runner.run(args)

        assert result.returncode == 0
        mock_run.assert_called_once()
        call_args = mock_run.call_args[0][0]
        assert "subtitles=" in " ".join(call_args)