"""
FFmpeg command execution and helper methods.
"""

import subprocess
import shlex
import os
from typing import List, Optional, Callable, Dict, Any
from .progress import ProgressTracker


class FFmpegRunner:
    """
    A runner for executing FFmpeg commands with helper methods for common tasks.
    """

    def __init__(self, ffmpeg_path: str = "ffmpeg"):
        """
        Initialize the FFmpeg runner.

        Args:
            ffmpeg_path: Path to the ffmpeg executable. Defaults to "ffmpeg".
        """
        self.ffmpeg_path = ffmpeg_path

    def run(self, args: List[str], progress_callback: Optional[Callable] = None) -> subprocess.CompletedProcess:
        """
        Run an FFmpeg command with the given arguments.

        Args:
            args: List of command line arguments for ffmpeg
            progress_callback: Optional callback function for progress updates

        Returns:
            CompletedProcess instance
        """
        cmd = [self.ffmpeg_path] + args

        if progress_callback:
            # Use progress tracker to parse stderr
            tracker = ProgressTracker(progress_callback)
            return tracker.run(cmd)
        else:
            return subprocess.run(cmd, capture_output=True, text=True)

    def convert(self, input_file: str, output_file: str, **kwargs) -> subprocess.CompletedProcess:
        """
        Convert a video/audio file to another format.

        Args:
            input_file: Path to input file
            output_file: Path to output file
            **kwargs: Additional ffmpeg options (e.g., video_codec='libx264', audio_codec='aac')

        Returns:
            CompletedProcess instance
        """
        args = ["-i", input_file]

        # Add common options
        if "video_codec" in kwargs:
            args.extend(["-c:v", kwargs["video_codec"]])
        if "audio_codec" in kwargs:
            args.extend(["-c:a", kwargs["audio_codec"]])
        if "video_bitrate" in kwargs:
            args.extend(["-b:v", kwargs["video_bitrate"]])
        if "audio_bitrate" in kwargs:
            args.extend(["-b:a", kwargs["audio_bitrate"]])

        # Add pixel format for video compatibility
        if kwargs.get("video_codec") or not kwargs.get("audio_only", False):
            args.extend(["-pix_fmt", "yuv420p"])

        # Fast start for MP4 files
        if output_file.endswith(('.mp4', '.m4v')):
            args.extend(["-movflags", "+faststart"])

        args.extend(["-y", output_file])  # -y to overwrite output files
        return self.run(args)

    def resize(self, input_file: str, output_file: str, width: int, height: int,
               **kwargs) -> subprocess.CompletedProcess:
        """
        Resize a video to the specified dimensions.

        Args:
            input_file: Path to input file
            output_file: Path to output file
            width: Target width
            height: Target height
            **kwargs: Additional options

        Returns:
            CompletedProcess instance
        """
        args = ["-i", input_file, "-vf", f"scale={width}:{height}"]

        # Add common options
        if "video_codec" in kwargs:
            args.extend(["-c:v", kwargs["video_codec"]])
        if "audio_codec" in kwargs:
            args.extend(["-c:a", kwargs["audio_codec"]])

        # Pixel format for compatibility
        args.extend(["-pix_fmt", "yuv420p"])

        # Fast start for MP4 files
        if output_file.endswith(('.mp4', '.m4v')):
            args.extend(["-movflags", "+faststart"])

        args.extend(["-y", output_file])
        return self.run(args)

    def compress(self, input_file: str, output_file: str, target_size_kb: int = None,
                 crf: int = 23, two_pass: bool = True, **kwargs) -> subprocess.CompletedProcess:
        """
        Compress a video file.

        Args:
            input_file: Path to input file
            output_file: Path to output file
            target_size_kb: Target file size in KB (approximate, requires two_pass=True)
            crf: Constant Rate Factor (0-51, lower = higher quality, ignored if target_size_kb set)
            two_pass: Use two-pass encoding for better quality at target size
            **kwargs: Additional options (audio_bitrate, preset, etc.)

        Returns:
            CompletedProcess instance
        """
        if target_size_kb and two_pass:
            return self._compress_two_pass(input_file, output_file, target_size_kb, **kwargs)
        else:
            return self._compress_single_pass(input_file, output_file, crf, **kwargs)

    def _compress_single_pass(self, input_file: str, output_file: str, crf: int, **kwargs) -> subprocess.CompletedProcess:
        """Single-pass compression using CRF."""
        args = ["-i", input_file]

        # Video codec and quality
        args.extend(["-c:v", "libx264", "-crf", str(crf)])

        # Preset for encoding speed vs compression efficiency
        preset = kwargs.get("preset", "medium")
        args.extend(["-preset", preset])

        # Pixel format for compatibility
        args.extend(["-pix_fmt", "yuv420p"])

        # Audio codec
        audio_codec = kwargs.get("audio_codec", "aac")
        args.extend(["-c:a", audio_codec])

        # Audio bitrate
        if "audio_bitrate" in kwargs:
            args.extend(["-b:a", kwargs["audio_bitrate"]])

        # Fast start for web playback
        if output_file.endswith(('.mp4', '.m4v')):
            args.extend(["-movflags", "+faststart"])

        args.extend(["-y", output_file])
        return self.run(args)

    def _compress_two_pass(self, input_file: str, output_file: str, target_size_kb: int, **kwargs) -> subprocess.CompletedProcess:
        """Two-pass compression for accurate target file size."""
        # Get input duration and audio info
        from .probe import FFprobeRunner
        ffprobe = FFprobeRunner()
        metadata = ffprobe.probe(input_file)

        duration = metadata.get("duration", 60)  # fallback to 60 seconds
        audio_bitrate = kwargs.get("audio_bitrate", "128k")

        # Calculate video bitrate (rough approximation)
        # Account for container overhead (~1%) and audio
        audio_bitrate_bps = self._parse_bitrate(audio_bitrate)
        total_audio_bits = audio_bitrate_bps * duration
        total_audio_kb = total_audio_bits / (8 * 1024)

        available_kb = target_size_kb - total_audio_kb
        video_bitrate_bps = int((available_kb * 8 * 1024) / duration)
        video_bitrate = f"{video_bitrate_bps}"

        # Pass 1: Analysis
        pass1_args = ["-i", input_file, "-c:v", "libx264", "-b:v", video_bitrate,
                     "-pass", "1", "-passlogfile", f"{output_file}.pass", "-f", "null", "/dev/null"]
        result1 = self.run(pass1_args)
        if result1.returncode != 0:
            return result1

        # Pass 2: Encoding
        pass2_args = ["-i", input_file, "-c:v", "libx264", "-b:v", video_bitrate,
                     "-pass", "2", "-passlogfile", f"{output_file}.pass",
                     "-pix_fmt", "yuv420p", "-c:a", "aac"]

        if "audio_bitrate" in kwargs:
            pass2_args.extend(["-b:a", kwargs["audio_bitrate"]])

        if output_file.endswith(('.mp4', '.m4v')):
            pass2_args.extend(["-movflags", "+faststart"])

        pass2_args.extend(["-y", output_file])
        result2 = self.run(pass2_args)

        # Clean up pass log file
        import os
        try:
            os.remove(f"{output_file}.pass")
        except OSError:
            pass

        return result2

    def _parse_bitrate(self, bitrate_str: str) -> int:
        """Parse bitrate string like '128k' to bits per second."""
        if bitrate_str.endswith('k'):
            return int(bitrate_str[:-1]) * 1024
        elif bitrate_str.endswith('M'):
            return int(float(bitrate_str[:-1]) * 1024 * 1024)
        else:
            return int(bitrate_str)

    def extract_audio(self, input_file: str, output_file: str, **kwargs) -> subprocess.CompletedProcess:
        """
        Extract audio from a video file.

        Args:
            input_file: Path to input video file
            output_file: Path to output audio file
            **kwargs: Additional options (e.g., audio_codec='aac', audio_bitrate='128k')

        Returns:
            CompletedProcess instance
        """
        args = ["-i", input_file, "-vn"]  # -vn = no video

        audio_codec = kwargs.get("audio_codec", "aac")  # Default to AAC for better compatibility
        args.extend(["-c:a", audio_codec])

        if "audio_bitrate" in kwargs:
            args.extend(["-b:a", kwargs["audio_bitrate"]])

        args.extend(["-y", output_file])
        return self.run(args)

    def get_version(self) -> str:
        """
        Get the FFmpeg version.

        Returns:
            Version string
        """
        result = subprocess.run([self.ffmpeg_path, "-version"],
                              capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout.split('\n')[0]
        else:
            raise RuntimeError(f"Failed to get FFmpeg version: {result.stderr}")