"""
Tests for FFmpegRunner.
"""

import pytest
from unittest.mock import patch, MagicMock
from pyffmpegcore.runner import FFmpegRunner


class TestFFmpegRunner:
    """Test FFmpegRunner functionality."""

    def test_init(self):
        """Test FFmpegRunner initialization."""
        runner = FFmpegRunner()
        assert runner.ffmpeg_path == "ffmpeg"

        runner = FFmpegRunner("/custom/path/ffmpeg")
        assert runner.ffmpeg_path == "/custom/path/ffmpeg"

    @patch('subprocess.run')
    def test_run(self, mock_run):
        """Test basic run method."""
        mock_run.return_value = MagicMock(returncode=0, stdout="output", stderr="")

        runner = FFmpegRunner()
        result = runner.run(["-version"])

        mock_run.assert_called_once()
        assert result.returncode == 0

    @patch('subprocess.run')
    def test_convert(self, mock_run):
        """Test convert method."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        runner = FFmpegRunner()
        result = runner.convert("input.mp4", "output.avi", video_codec="libx264")

        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert "-i" in args
        assert "input.mp4" in args
        assert "output.avi" in args
        assert "-c:v" in args
        assert "libx264" in args

    @patch('subprocess.run')
    def test_resize(self, mock_run):
        """Test resize method."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        runner = FFmpegRunner()
        result = runner.resize("input.mp4", "output.mp4", 640, 480)

        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert "-vf" in args
        assert "scale=640:480" in args

    @patch('subprocess.run')
    def test_compress(self, mock_run):
        """Test compress method."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        runner = FFmpegRunner()
        result = runner.compress("input.mp4", "output.mp4", crf=28)

        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert "-c:v" in args
        assert "libx264" in args
        assert "-crf" in args
        assert "28" in args

    @patch('subprocess.run')
    def test_extract_audio(self, mock_run):
        """Test extract_audio method."""
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        runner = FFmpegRunner()
        result = runner.extract_audio("input.mp4", "output.mp3")

        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert "-vn" in args  # no video
        assert "-c:a" in args
        assert "aac" in args  # Now defaults to AAC

    @patch('subprocess.run')
    def test_get_version(self, mock_run):
        """Test get_version method."""
        mock_run.return_value = MagicMock(returncode=0, stdout="ffmpeg version 4.4\n", stderr="")

        runner = FFmpegRunner()
        version = runner.get_version()

        assert "ffmpeg version 4.4" in version